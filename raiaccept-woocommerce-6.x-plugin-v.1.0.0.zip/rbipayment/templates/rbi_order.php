<div>
	<?php if (RBIFlashMessages::registry('post_status')) { ?>
		<script>alert('<?php echo addslashes(RBIFlashMessages::registry('post_status')); ?>');</script>
		<br /><b><?php echo RBIFlashMessages::registry('post_status'); ?></b>
	<?php } ?>
	<form action="" method="post">
		<table id="rbi-table">
			<tbody>
				<tr>
					<td><?php _e('Mode', 'rbipayment'); ?></td>
					<td><strong><?php echo $mode; ?></strong></td>
				</tr>
				<?php if ($rbi_order->getValue('refunded_amount') < $rbi_order->getValue('request')['invoice']['amount'] && $rbi_order->getValue('response')['transaction']['status'] == 'SUCCESS') { ?>
				<tr id="input-fields">
					<td><?php _e('Amount', 'rbipayment'); ?> (<?php echo $rbi_order->getValue('currency'); ?>)</td>
					<td>
						<input type="number" name="rbi_amount" id="rbi_amount" value="" placeholder="<?php echo $rbi_order->getValue('currency'); ?>"/>
						<button type="button" id="refund_partial" class="button-primary"><?php _e('Partial Refund', 'rbipayment'); ?></button>
						<button type="button" id="refund_full" class="button-primary"><?php _e('Refund the full amount', 'rbipayment'); ?></button>
					</td>
				</tr>
				<?php } ?>
				<?php if ($rbi_order->getValue('refunded_amount')) { ?>
				<tr class="refunded-amount">
					<td><?php _e('Refunded amount', 'rbipayment'); ?></td>
					<td><strong><?php echo $refunded_amount; ?></strong></td>
				</tr>
				<?php } ?>
				<tr class="status-row">
					<td><?php _e('All Transactions Statuses', 'rbipayment'); ?></td>
					<td><button type="button" id="check_last_tr_status" class="button-secondary"><?php _e('Check', 'rbipayment'); ?></button></td>
				</tr>
			</tbody>
		</table>
	</form>
</div>
<script type="text/javascript">//<!--
	function refund(amount) {
		jQuery('#rbi_amount').addClass('loading');
		jQuery('#input-fields button').prop('disabled', true);

		jQuery.ajax({
			url: 'admin-ajax.php',
			type: 'GET',
			data: {
				action: 'rbipayment_refund',
				rbi_amount: amount,
				order_id: '<?php echo $order_id; ?>',
			},
			dataType: 'json',
			contentType: 'application/json',
			success: function(json) {
				jQuery('#rbi_amount').removeClass('loading');
				jQuery('#input-fields button').prop('disabled', false);

				if (typeof json.error != 'undefined') {
					alert(json.error);
				} else if(typeof json.success != 'undefined') {
					jQuery('#rbi_amount').val('');

					if (json.hide_input_fields) {
						jQuery('#input-fields').remove();
					}

					jQuery('.refunded-amount').remove();
					jQuery('#rbi-table tbody .status-row').before('<tr class="refunded-amount"><td><?php _e('Refunded amount', 'rbipayment'); ?></td><td id="amount"><strong>' + json.amount + '</strong></td></tr>');

					alert(json.success);
				}
			}
		});
	}

	jQuery('#refund_partial').on('click', function() {
		var rbiAmount = jQuery('#rbi_amount').val();

		if (rbiAmount != '' && rbiAmount != '0') {
			refund(rbiAmount);
		} else {
			alert('<?php echo __('The amount must be more than 0!', 'rbipayment'); ?>');
		}
	});

	jQuery('#refund_full').on('click', function() {
		refund(0);
	});

	jQuery('#check_last_tr_status').on('click', function() {
		var timezone_offset_minutes = new Date().getTimezoneOffset();
		timezone_offset_minutes = timezone_offset_minutes == 0 ? 0 : -timezone_offset_minutes;
		jQuery('#check_last_tr_status').addClass('loading');

		jQuery.ajax({
			url: 'admin-ajax.php',
			dataType: 'json',
			data: {
				timezone_offset: timezone_offset_minutes * 60,
				action: 'rbipayment_status',
				order_id: '<?php echo $order_id; ?>',
			},
			success: function(json) {
				if (typeof json.error != 'undefined') {
					alert(json.error);
				} else {
					jQuery('#status-content').remove();
					var tr_status = document.createElement('tr');
					tr_status.className = 'status-content';
					var td_status = document.createElement('td');
					td_status.setAttribute('colspan', '2');

					var table = document.createElement('table');
					table.className = 'table table-bordered';
					var tbody = document.createElement('tbody');
					var tr, td1, td2 = '';
					var keys = Object.keys(json);

					for (key in json) {
						transaction = json[key];

						for (trKey in transaction) {
							tr = document.createElement('tr');
							td1 = document.createElement('td');
							td1.className = 'textright';
							td2 = document.createElement('td');

							td1.innerText = transaction[trKey]['entry'];
							tr.append(td1);
							td2.innerText = transaction[trKey]['value'];
							tr.append(td2);

							tbody.append(tr);
						}

						if (key != keys[keys.length - 1]) {
							jQuery(tbody).append('<tr class="delimiter"><td colspan="2">&nbsp;</td></tr>');
						}
					}

					table.append(tbody);
					td_status.append(table);
					tr_status.append(td_status);
					jQuery('.status-content').remove();
					jQuery('.status-row').after(tr_status);
					jQuery('#check_last_tr_status').removeClass('loading');
				}
			}
		});
	});
//--></script>
