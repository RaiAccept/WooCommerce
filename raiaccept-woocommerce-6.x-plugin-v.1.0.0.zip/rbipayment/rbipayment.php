<?php
/*
Plugin Name: Card Payments
Description: Raiffeisen Bank Payment Gateway
Version:	 1.0.0
Author:	  Extensa Web Development
Author URI:  http://extensadev.com
Copyright:   (c) 2023 RBI

Text Domain: rbipayment
Domain Path: /languages/
*/

defined('ABSPATH') or die('No script kiddies please!');

$woocommerce_active = false;

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	$woocommerce_active = true;
} elseif ( is_multisite() && array_key_exists( 'woocommerce/woocommerce.php', get_site_option('active_sitewide_plugins') ) ) {
	$woocommerce_active = true;
} else {
	$woocommerce_active = false;
}

if (!$woocommerce_active) {
	return;
}

add_action ( 'wp_ajax_rbipayment_status', ['WC_Gateway_Rbipayment', 'status'] );
add_action ( 'wp_ajax_rbipayment_refund', ['WC_Gateway_Rbipayment', 'refund'] );

final class RBIPayment
{
	static private $_instance = null;
	static public $preventSave = null;
	static public $invalidFields = array();

	public $rbi;

	private function __construct() {
		include_once('includes/class-flash-messages.php');
		include_once('includes/class-rbipayment-order.php');
		include_once('includes/lib/rbi.php');

		register_activation_hook(__FILE__, array($this, 'install_rbi'));

		add_filter('plugin_action_links_' . plugin_basename( __FILE__ ), array($this, 'plugin_action_links'));
		add_action('plugins_loaded', array($this, 'init'), 0);
		add_filter('woocommerce_payment_gateways', array($this, 'register_gateway'));
		add_action('admin_head', array($this, 'plugin_admin_menu'));
		add_filter('pre_option_woocommerce_rbipayment_settings', array($this, 'validateSave'));

		$post_id = false;
		if (!empty($_POST['post_ID'])) {
			$post_id = $_POST['post_ID'];
		} else if (!empty($_GET['post'])) {
			$post_id = $_GET['post'];
		}

		$rbiOrder = Rbipayment_Order::getByOrderId($post_id);
		if ($post_id && $rbiOrder->exists() && $rbiOrder->getValue('response')) {
			add_action('add_meta_boxes', function() {
				add_meta_box( 'woocommerce-rbi-data', __( 'Card Payments', 'rbipayment'), ['WC_Gateway_Rbipayment', 'orderInfo'], 'shop_order', 'normal', 'high' );
			});
		}

		$this->rbi = new Rbi();
	}

	static public function getInstance() {
		if (self::$_instance === null) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function init() {
		if (!class_exists('WC_Payment_Gateway')) {
			return;
		}

		include_once('includes/class-wc-gateway-rbipayment.php');

		load_plugin_textdomain('rbipayment', false, dirname(plugin_basename(__FILE__)) . '/languages');
	}

	public function install_rbi() {
		Rbipayment_Order::createTableIfNotExists();
	}

	public function plugin_action_links($links) {
		$plugin_links = array(
			'<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=rbipayment') . '">' . __('Settings', 'rbipayment') . '</a>',
		);

		return array_merge($plugin_links, $links);
	}

	public function register_gateway($methods) {
		$methods[] = 'WC_Gateway_Rbipayment';
		return $methods;
	}

	public function plugin_admin_menu() {
		wp_register_style('rbipayment', plugins_url('rbipayment/assets/css/admin.css'));
		wp_enqueue_style('rbipayment');
		wp_register_script('rbipayment', plugins_url('rbipayment/assets/js/admin.js'));
		wp_enqueue_script('rbipayment');
	}

	public function validateSave() {
		if (!is_admin()) {
			return false;
		}

		if (isset($_POST['woocommerce_rbipayment_description'])) {
			if (self::$preventSave === false) {
				return false;
			}

			if (self::$preventSave) {
				return self::$preventSave;
			}

			$settings = array();

			$fieldsToValidate = [
				'description' => [
					'rule' => function($value) {return mb_strlen($value) > 200;},
					'error' => __('Your description must not be more than 200 symbols!', 'rbipayment'),
				],
				'currency_rate' => [
					'rule' => function($value) {
						$valid_currencies = get_woocommerce_currencies();
						$valid = true;

						foreach($value as $currency) {
							$valid = isset($valid_currencies[$currency['iso_code']]);
							$valid = $currency['rate'] <= 0 ? false : $valid;
							if (!$valid) {
								break;
							}
						}

						return !$valid;
					},
					'error' => __('ISO code must be valid and currency rate must not be 0!', 'rbipayment'),
				],
			];

			foreach ($_POST as $key => $value) {
				if (strpos($key, 'woocommerce_rbipayment_') !== 0) {
					continue;
				}

				$field = substr($key, strlen('woocommerce_rbipayment_'));

				if (isset($fieldsToValidate[$field])) {
					if ($fieldsToValidate[$field]['rule']($value)) {
						WC_Admin_Settings::add_error($fieldsToValidate[$field]['error']);
						self::$invalidFields[] = $field;
					}
				}

				if (is_array($value)) {
					$value = maybe_serialize($value);
				}

				$settings[$field] = htmlspecialchars($value);
			}

			$mode = $_POST[$this->rbi->prefix . 'mode'];
			if (!$_POST[$this->rbi->prefix . $mode . '_username']) {
				WC_Admin_Settings::add_error(__('Username Required!', 'rbipayment'));
				self::$invalidFields[] = $mode . '_username';
			}

			if (!$_POST[$this->rbi->prefix . $mode . '_password']) {
				WC_Admin_Settings::add_error(__('Password Required!', 'rbipayment'));
				self::$invalidFields[] = $mode . '_password';
			}

			if (empty(self::$invalidFields) && !$this->rbi->retrieveToken($_POST[$this->rbi->prefix . $mode . '_username'], $_POST[$this->rbi->prefix . $mode . '_password'])) {
				WC_Admin_Settings::add_error(__('Invalid Username or Password!', 'rbipayment'));
				self::$invalidFields[] = $mode . '_password';
			}

			Rbipayment_Order::createTableIfNotExists();

			if (!self::$invalidFields) {
				self::$preventSave = false;
				return false;
			}

			self::$invalidFields = array_flip(self::$invalidFields);

			self::$preventSave = $settings;

			return $settings;
		}

		return false;
	}
}

RBIPayment::getInstance();
