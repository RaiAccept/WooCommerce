jQuery( document ).on('updated_checkout', function() {
	if (!rbi.description) {
		jQuery('.payment_method_rbipayment.payment_box').addClass('hidden');
	}
});

jQuery( document ).ajaxComplete(function( event, xhr, settings ) {
	if ( settings.url.indexOf('wc-ajax=checkout') != -1 ) {
		data = xhr.responseJSON;
		if (data.action && data.payment_method == rbi.id) {
			jQuery('.woocommerce-error').hide();
			jQuery('#rbi-modal iframe').attr('src', data.action);
			jQuery('#rbi-modal').modal({backdrop: 'static', keyboard: false}, 'show');
			jQuery('.modal-backdrop.in').after(jQuery('#rbi-modal'));
			jQuery('html').css('overflow', 'hidden');
		}
	}
});

function closeIframePopup(redirectURL = '') {
	jQuery('#rbi-modal').modal('hide');
	jQuery('html').css('overflow', 'auto');

	if (redirectURL) {
		location = redirectURL;
	}
}