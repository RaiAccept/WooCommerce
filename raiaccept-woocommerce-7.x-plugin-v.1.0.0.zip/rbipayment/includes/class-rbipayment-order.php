<?php
/**
 * Raiffeisenbank International payment module
 *
 * @author Extensa Web Development Ltd. <support@extensadev.com>
 * @copyright Copyright (c) 2023 RBI
*/

class Rbipayment_Order
{
	const RBI_TABLE_NAME = 'rbi_order';

	private $id;
	private $data = array();

	public function __construct($id, $data = false)
	{
		global $wpdb;

		if ($data === false) {
			$sql = $wpdb->prepare("SELECT * FROM `" . $wpdb->prefix . self::RBI_TABLE_NAME . "` WHERE `orderIdentification` = %s LIMIT 1", $id);
			$data = $wpdb->get_row($sql, ARRAY_A);
		}

		if (isset($data['orderIdentification']) && $data['orderIdentification']) {
			$this->id = $data['orderIdentification'];
		}

		$data['request'] = !empty($data['request']) ? maybe_unserialize($data['request']) : [];
		$data['response'] = !empty($data['response']) ? maybe_unserialize($data['response']) : [];
		$data['refund_response'] = !empty($data['refund_response']) ? maybe_unserialize($data['refund_response']) : [];

		$this->data = $data;
	}

	public function exists() {
		return (bool) $this->id;
	}

	public function setValue($key, $value) {
		$this->data[$key] = $value;
		return $this;
	}

	public function getValue($key) {
		if (isset($this->data[$key])) {
			if (in_array($key, ['request', 'response', 'refund_response'])) {
				return maybe_unserialize($this->data[$key]);
			}
			return $this->data[$key];
		}

		return null;
	}

	public function save() {
		global $wpdb;

		$this->data['request'] = maybe_serialize($this->data['request']);
		$this->data['response'] = maybe_serialize($this->data['response']);
		$this->data['refund_response'] = maybe_serialize($this->data['refund_response']);

		$table_name = $wpdb->prefix . self::RBI_TABLE_NAME;

		if ($this->exists()) {
			$wpdb->update($table_name, $this->data, array('orderIdentification' => $this->id));
		} else {
			$wpdb->insert($table_name, $this->data);
		}
	}

	public static function getRbiOrder($orderIdentification) {
		global $wpdb;

		$sql = $wpdb->prepare("SELECT * FROM `" . $wpdb->prefix . self::RBI_TABLE_NAME . "` WHERE `orderIdentification` = %s LIMIT 1", $orderIdentification);
		$row = $wpdb->get_row($sql, ARRAY_A);

		$rbiOrderId = null;
		if (isset($row['orderIdentification'])) {
			$rbiOrderId = $row['orderIdentification'];
		}

		$order = new Rbipayment_Order($rbiOrderId, $row);
		$order->setValue('orderIdentification', $orderIdentification);

		return $order;
	}

	public static function getByOrderId($order_id) {
		global $wpdb;

		$table_name = $wpdb->prefix . self::RBI_TABLE_NAME;
		$query = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

		if ( $wpdb->get_var( $query ) != $table_name ) {
			return;
		}

		$sql = $wpdb->prepare("SELECT * FROM `" . $table_name . "` WHERE `order_id` = %s LIMIT 1", $order_id);
		$row = $wpdb->get_row($sql, ARRAY_A);

		$rbiOrderId = null;
		if (isset($row['orderIdentification'])) {
			$rbiOrderId = $row['orderIdentification'];
		}

		$order = new Rbipayment_Order($rbiOrderId, $row);
		$order->setValue('order_id', $order_id);

		return $order;
	}

	public static function createTableIfNotExists() {
		global $wpdb;

		$table_name = $wpdb->prefix . self::RBI_TABLE_NAME;
		$query = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

		if ( $wpdb->get_var( $query ) != $table_name ) {
			self::createTable();
		}
	}

	public static function createTable() {
		global $wpdb;

		$table_name = $wpdb->prefix . self::RBI_TABLE_NAME;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			`id` int(11) NOT NULL AUTO_INCREMENT,
			`order_id` int(11) NOT NULL,
			`mode` varchar(63) NOT NULL DEFAULT '',
			`request` TEXT NOT NULL DEFAULT '',
			`response` TEXT NOT NULL DEFAULT '',
			`orderIdentification` varchar(255) NOT NULL DEFAULT '',
			`phpsessid` varchar(255) NOT NULL DEFAULT '',
			`currency` varchar(255),
			`currency_value` varchar(255),
			`refunded_amount` varchar(255) DEFAULT 0,
			`refund_response` TEXT NOT NULL DEFAULT '',
			`date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY (`id`),
			KEY `order_id` (`order_id`)
		) $charset_collate;";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
		dbDelta("ALTER TABLE `$table_name` ADD UNIQUE( `order_id`);");
	}
}
