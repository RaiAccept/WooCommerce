<?php
/**
 * Raiffeisenbank International payment module
 *
 * @author RaiAccept <support@raiaccept.com>
 * @copyright Copyright (c) 2023 RBI
*/

if (!defined('ABSPATH')) {
	exit;
}

use Rbi as RbiLib;

class WC_Gateway_Rbipayment extends WC_Payment_Gateway
{
	public $rbi;
	public $rbi_currency;

	public $action = '';
	public $version = '1.0.0';

	public function __construct() {
		include_once('lib/rbi.php');

		$this->rbi = new Rbi();
		$this->id = 'rbipayment';
		$this->method_title = __('Card Payments', 'rbipayment');
		$this->method_description = __('Raiffeisen Bank Payment Gateway', 'rbipayment');
		$this->icon = get_site_url() . '/wp-content/plugins/rbipayment/assets/rbi.png';
		$this->has_fields = $this->rbi->get('payment_form') == 'iframe';
		$this->supports = [
			'products'
		];

		$this->init_form_fields();
		$this->init_settings();

		$this->title = __('Card Payments', 'rbipayment');
		$this->rbi_currency = $this->rbi->get('currency') !== '0' ? $this->rbi->get('currency') : get_woocommerce_currency();

		foreach ($this->settings as $key => $val) {
			$this->$key = $val;
		}

		add_action('admin_notices', array($this, 'errors'));
		add_action('woocommerce_before_checkout_form', array($this, 'errors'));
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

		if (is_checkout() && $this->enabled == 'yes' && $this->has_fields()) {
			wp_enqueue_script( 'rbi_iframe', plugin_dir_url(__DIR__) . 'assets/js/iframe.js', array('jquery'), '1.0.0', true );
			wp_localize_script( 'rbi_iframe', 'rbi', [
				'id' => $this->id,
				'description' => $this->get_description(),
			]);
			wp_register_style('rbipayment', plugin_dir_url(__DIR__) . 'assets/css/iframe.css');
			wp_enqueue_style('rbipayment');
		}

		foreach(['success', 'failure', 'notify', 'cancel'] as $action) {
			$this->add_callback_action($action);
		}
	}

	public function get_description() {
		return __('Pay with the most used credit and debit cards.', 'rbipayment');
	}

	public function add_callback_action($type) {
		add_action( "woocommerce_api_wc_gateway_rbipayment_$type", array( $this, $type ) );
	}

	public function callback($type) {
		return add_query_arg( 'wc-api', "wc_gateway_rbipayment_$type", home_url( '/' ) );
	}

	public static function orderInfo( $post ) {
		$order = wc_get_order($post->ID);
		$rbiOrder = Rbipayment_Order::getByOrderId($order->get_id());

		$data['order_id'] = $order->get_id();
		$data['rbi_order'] = $rbiOrder;
		$data['mode'] = __('text_' . $rbiOrder->getValue('mode'), 'rbipayment');

		$refunded_amount = number_format((float)$rbiOrder->getValue('refunded_amount'), 2, '.', '');
		$paid_amount = number_format($rbiOrder->getValue('request')['invoice']['amount'], 2, '.', '');
		$currency = $rbiOrder->getValue('currency');

		$data['refunded_amount'] = "$refunded_amount $currency " . __('out of', 'rbipayment') . " $paid_amount $currency";

		wc_get_template( 'rbi_order.php',
			$data,
			'',
			plugin_dir_path(__DIR__) . '/templates/'
		);
	}

	public static function refund() {
		$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : 0;
		$rbi_order = Rbipayment_Order::getByOrderId($order_id);
		$order = wc_get_order($order_id);

		$rbi = new Rbi();
		$json = [];

		if ($rbi_order && $order && isset($_GET['rbi_amount'])) {
			$rbiAmount = str_replace(',', '.', $_GET['rbi_amount']);
			$currencyCode = $rbi_order->getValue('currency');

			if (is_numeric($rbiAmount)) {
				$request = $rbi_order->getValue('request');
				$amount = $request['invoice']['amount'];

				$left_for_refund = $amount - $rbi_order->getValue('refunded_amount');
				if ($rbiAmount > $left_for_refund) {
					$json['error'] = __('Requested amount is unavailable. %s %s left for refund.', 'rbipayment');
					$json['error'] = sprintf($json['error'], number_format($left_for_refund, 2, '.', ''), $currencyCode);
				}

				if ($rbiAmount > $amount) {
					$json['error'] = __('You can not refund more than the paid amount', 'rbipayment');
				}

				if ($rbiAmount < 0) {
					$json['error'] = __('Refund amount has to be greater than 0', 'rbipayment');
				}

				if (!isset($json['error'])) {
					$amount = $rbiAmount == '0' ? $amount - $rbi_order->getValue('refunded_amount') : $rbiAmount;

					$data = [
						'amount' => round($amount, 2),
						'currency' => $currencyCode
					];

					$curl = $rbi->curl(
						json_encode($data),
						$rbi->getRefundUrl($rbi_order),
						[
							"Accept: application/json",
							"Content-Type: application/json",
							"Authorization: Bearer " . $rbi->getBearerToken()
						]
					);

					$transactionId = isset($curl['response']['transactionId']) ? $curl['response']['transactionId'] : '';
					if (!$transactionId) {
						$json['error'] = __('An error occurred on request:', 'rbipayment');
						$json['error'] .= PHP_EOL . $curl['response']['message'];
						echo json_encode($json);
						die;
					}

					sleep(1);
					$curl = $rbi->curl(
						[],
						$rbi->getStatusUrl($rbi_order, $transactionId),
						[
							"Accept: application/json",
							"Authorization: Bearer " . $rbi->getBearerToken()
						]
					);

					$response = $curl['response'];
					$refunded_amount = 0;

					if ($response['transaction']['status'] == 'SUCCESS') {
						$refunded_amount = number_format($rbi_order->getValue('refunded_amount') + $amount, 2, '.', '');
						$paid_amount = number_format($request['invoice']['amount'], 2, '.', '');
						$amount = number_format($amount, 2, '.', '');

						$json['success'] = sprintf(__('Successfully refunded %s %s', 'rbipayment'), $amount, $currencyCode);
						$json['amount'] = "$refunded_amount $currencyCode " . __('out of', 'rbipayment') . " $paid_amount $currencyCode";
						$json['hide_input_fields'] = $refunded_amount >= $request['invoice']['amount'];
					} else {
						if (__('text_trans_code_' . $response['transaction']['statusCode'], 'rbipayment')) {
							$text_error = __('text_trans_code_' . $response['transaction']['statusCode'], 'rbipayment');
						} else {
							$text_error = '';
						}

						$json['error'] = sprintf(__('Failed attempt: (%s)', 'rbipayment'), $response['transaction']['statusCode']);
						$json['error'] .= PHP_EOL . $text_error;
					}
				}
			} else {
				$json['error'] = __('Enter a valid number', 'rbipayment');
			}
		} else {
			$json['error'] = __('Raiffeisen Bank order is missing or it is already refunded', 'rbipayment');
		}

		echo json_encode($json);die;
	}

	public static function status() {
		$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : 0;
		$rbi_order = Rbipayment_Order::getByOrderId($order_id);
		$response = [];

		$rbi = new Rbi();

		if ($rbi_order->exists()) {
			$curl = $rbi->curl(
				[],
				$rbi->getOrderStatusesUrl($rbi_order),
				[
					"Accept: application/json",
					"Authorization: Bearer " . $rbi->getBearerToken()
				]
			);

			$timezone_name = timezone_name_from_abbr("", $_GET['timezone_offset'], false);
			date_default_timezone_set($timezone_name);

			$total_refunded = 0;

			foreach($curl['response'] as $transaction) {
				if (__('text_trans_code_' . $transaction['statusCode'], 'rbipayment')) {
					$status = __('text_trans_code_' . $transaction['statusCode'], 'rbipayment');
				} else {
					$status = $transaction['statusMessage'];
				}

				if ($transaction['transactionType'] == 'REFUND' && $transaction['status'] == 'SUCCESS') {
					$total_refunded += $transaction['transactionAmount'];
				}

				$ts = strtotime($transaction['createdOn']);
				$transactionAmount = number_format($transaction['transactionAmount'], 2, '.', '');

				$response[$ts] = [
					'id' => ['entry' => __('text_transaction_id', 'rbipayment'), 'value' => $transaction['transactionId']],
					'type' => ['entry' => __('text_transaction_type', 'rbipayment'), 'value' => $transaction['transactionType']],
					'date' => ['entry' => __('text_transaction_date', 'rbipayment'), 'value' => date('d.m.Y H:i:s', $ts)],
					'amount' => ['entry' => __('text_transaction_amount', 'rbipayment'), 'value' => $transactionAmount . ' ' . $transaction['transactionCurrency']],
					'status' => ['entry' => __('text_transaction_status', 'rbipayment'), 'value' => $transaction['status'] . ': ' . $status],
				];
			}

			$rbi_order->setValue('refunded_amount', $total_refunded)->save();

			ksort($response);
		} else {
			$response['error'] = __('Raiffeisen Bank order is missing or it is already refunded', 'rbipayment');
		}

		echo json_encode($response);die;
	}

	public function errors() {
		$messages = RBIFlashMessages::getMessages();
		if ($messages) {
			foreach ($messages as $message)  {
				echo '<div class="' . $message['type'] . '">' . $message['message'] . '</div>';
			}
		}
	}

	/**
	 * Generate Currencies HTML.
	 */
	function generate_currency_rate_html( $key, $data ) {
		$field = $this->plugin_id . $this->id . '_' . $key;
		$defaults = array(
			'title'			 => '',
			'class'			 => '',
			'css'			   => '',
			'custom_attributes' => array(),
			'desc_tip'		  => false,
			'description'	   => '',
			'options'		   => array(),
		);

		$data = wp_parse_args( $data, $defaults );
		$maybeHide = empty($this->rbi->get('currency')) ? 'hide-all' : '';

		ob_start();
		?>
		<?php $row = 0; ?>
		<?php foreach ($data['options'] as $value) { ?>
		<tr valign="top" style="<?php echo esc_attr( $data['css'] ); ?>" id="currency_row_<?php echo $row; ?>">
			<th scope="row" class="titledesc textright">
				<?php echo esc_attr( $data['title'] ); ?>
			</th>
			<td class="forminp">
				<input type="text" style="width: 75px;" class="<?php echo $field; ?>" name="<?php echo $field; ?>[<?php echo $row; ?>][iso_code]" placeholder="<?php echo __( 'ISO Code', 'rbipayment' ); ?>" value="<?php echo $value['iso_code']; ?>" />
				<input type="text" style="width: 250px;" class="<?php echo $field; ?>" name="<?php echo $field; ?>[<?php echo $row; ?>][rate]" placeholder="<?php echo __( 'Rate', 'rbipayment' ); ?>" value="<?php echo $value['rate']; ?>" />
				<button type="button" class="button remove_currency" onclick="jQuery('#currency_row_<?php echo $row; ?>').remove();"><?php echo __( 'Remove', 'rbipayment' ); ?></button>
				<p class="description"><?php echo sprintf(__( 'Point the value to which 1 <span class="currency">%s</span> is equal to', 'rbipayment' ), $this->rbi->get('currency')); ?></p>
			</td>
		</tr>
		<?php $row++; ?>
		<?php } ?>
		<tr valign="top" id="add_rate" class="<?php echo $maybeHide; ?>">
			<th scope="row" class="titledesc">
			</th>
			<td class="forminp">
				<button type="button" class="button" onclick="addRate();"><?php echo __( 'Add Currency / Currency Rate', 'rbipayment' ); ?></button>
			</td>
		</tr>
		<script type="text/javascript">//<!--
			var row = <?php echo $row; ?>;
			function addRate() {
				html =  '<tr valign="top" style="<?php echo esc_attr( $data['css'] ); ?>" id="currency_row_' + row + '">';
				html += '  <th scope="row" class="titledesc textright">';
				html += '	<?php echo esc_attr( $data['title'] ); ?>';
				html += '  </th>';
				html += '  <td class="forminp">';
				html += '	<input type="text" style="width: 75px;" class="<?php echo $field; ?>" name="<?php echo $field; ?>[' + row + '][iso_code]" placeholder="<?php echo __( 'ISO Code', 'rbipayment' ); ?>" value="" />';
				html += '	<input type="text" style="width: 250px;" class="<?php echo $field; ?>" name="<?php echo $field; ?>[' + row + '][rate]" placeholder="<?php echo __( 'Rate', 'rbipayment' ); ?>" value="" />';
				html += '	<button type="button" class="button remove_currency" onclick="jQuery(\'#currency_row_' + row + '\').remove();"><?php echo __( 'Remove', 'rbipayment' ); ?></button>';
				html += '	<p class="description"><?php echo __( 'Point the value to which 1 <span class="currency">%s</span> is equal to', 'rbipayment' ); ?></p>';
				html += '  </td>';
				html += '</tr>';

				jQuery('#add_rate').before(html);
				jQuery('.currency').text(jQuery('#woocommerce_rbipayment_currency').val());
				row++;
			}
		//--></script>
		<?php
		return ob_get_clean();
	}

	function validate_currency_rate_field( $key ) {
		$field = $this->get_field_key( $key );

		if ( isset( $_POST[ $field ] ) ) {
			if (is_array($_POST[ $field ])) {
				foreach ($_POST[ $field ] as $p_field) {
					$value[] = array_map( 'wc_clean', array_map( 'stripslashes', (array) $p_field ) );
				}
			}
		} else {
			$value = '';
		}

		return $value;
	}

	function generate_info_html( $key, $data ) {
		ob_start();
		?>
			<tr valign="top">
				<th scope="row" class="titledesc textright"><strong><?php echo $data['title']; ?></strong></th>
				<td class="forminp"><?php echo $data['label']; ?></td>
			</tr>
		<?php

		return ob_get_clean();
	}

	function generate_tabs_html( $key, $data ) {
		ob_start();
		?>
			<nav class="rbi nav-tab-wrapper woo-nav-tab-wrapper">
				<a class="nav-tab nav-tab-active" href="#tab-general" data-bs-toggle="tab"><?php echo __('General', 'rbipayment'); ?></a>
				<a class="nav-tab" href="#tab-advanced" data-bs-toggle="tab"><?php echo __('Advanced settings', 'rbipayment'); ?></a>
			</nav>
		<?php

		return ob_get_clean();
	}

	public function init_form_fields() {
		global $wp_version;
		global $woocommerce;

		$zones = WC_Shipping_Zones::get_zones();
		$default_zone = new WC_Shipping_Zone(0);
		$default_zone = $default_zone->get_data();
		$zonesOption = array(
			'-1' => 'All zones',
			'0'  => $default_zone['zone_name']
		);

		foreach ($zones as $zoneKey => $zoneVal) {
			$zonesOption[$zoneKey] = $zoneVal['zone_name'];
		}

		$currency_rate = array();

		if (!empty($this->rbi->get('currency_rate'))) {
			foreach ($this->rbi->get('currency_rate') as $key => $value) {
				$currency_rate[$key] = array(
					'iso_code' => $value['iso_code'],
					'rate'	 => $value['rate'],
				);
			}
		}

		$common_settings_fields = array(
			array(
				'title' => '',
				'type'  => 'tabs',
			),
			array(
				'title' => __('API settings', 'rbipayment'),
				'type'  => 'title',
				'class' => 'tab-general',
			),
			'mode' => array(
				'title'   => __('Select Mode:', 'rbipayment'),
				'type'    => 'select',
				'options' => [
					'sandbox'    => __('text_sandbox', 'rbipayment'),
					'production' => __('text_production', 'rbipayment')
				],
				'default' => 'sandbox',
			),
			'sandbox_username' => array(
				'title' => __('Sandbox Username:', 'rbipayment'),
				'type'  => 'text',
				'class' => isset(RBIPayment::$invalidFields['sandbox_username']) || isset(RBIPayment::$invalidFields['sandbox_password']) ? 'rbipayment-error-field' : '',
			),
			'sandbox_password' => array(
				'title' => __('Sandbox Password:', 'rbipayment'),
				'type'  => 'password',
				'class' => isset(RBIPayment::$invalidFields['sandbox_password']) ? 'rbipayment-error-field' : '',
			),
			'production_username' => array(
				'title' => __('Production Username:', 'rbipayment'),
				'type'  => 'text',
				'class' => isset(RBIPayment::$invalidFields['production_username']) || isset(RBIPayment::$invalidFields['production_password']) ? 'rbipayment-error-field' : '',
			),
			'production_password' => array(
				'title' => __('Production Password:', 'rbipayment'),
				'type'  => 'text',
				'class' => isset(RBIPayment::$invalidFields['production_password']) ? 'rbipayment-error-field' : '',
			),
			array(
				'title' => __('General settings', 'rbipayment'),
				'type'  => 'title',
				'class' => 'tab-general',
			),
			'payment_form' => array(
				'title'   => __('Payment form integration:', 'rbipayment'),
				'type'    => 'select',
				'options' => [
					'iframe'   => __('Iframe', 'rbipayment'),
					'redirect' => __('Redirect', 'rbipayment')
				]
			),
			'currency' => array(
				'title'   => __('Payment Currency:', 'rbipayment'),
				'type'	=> 'select',
				'options' => array_merge(['0' => __('-- none --', 'rbipayment')], get_woocommerce_currencies()),
				'default' => '0'
			),
			'currency_rate' => array(
				'title'   => __('Currency rate', 'rbipayment'),
				'type'    => 'currency_rate',
				'options' => $currency_rate,
			),
			'enabled' => array(
				'title'   => __('Plugin Status:', 'rbipayment'),
				'type'    => 'checkbox',
				'label'   => __('Enabled', 'rbipayment'),
				'default' => 'yes'
			),
			array(
				'title' => __('Contact Details RaiAccept', 'rbipayment'),
				'type'  => 'title',
				'class' => 'tab-general',
			),
			array(
				'title' => __('Website:', 'rbipayment'),
				'type'  => 'info',
				'label' => '<a href="https://www.raiaccept.com">https://www.raiaccept.com</a>',
			),
			array(
				'title' => __('Email:', 'rbipayment'),
				'type'  => 'info',
				'label' => '<a href="mailto:support@raiaccept.com">support@raiaccept.com</a>',
			),
			array(
				'title' => __('Plugin Version:', 'rbipayment'),
				'type'  => 'info',
				'label' => "Wordpress: $wp_version, Woocommerce: {$woocommerce->version}, Plugin: {$this->version}",
			),
			array(
				'title' => __('Order Statuses', 'rbipayment'),
				'type'  => 'title',
				'class' => 'tab-advanced',
			),
		);

		$order_statuses = wc_get_order_statuses();

		$typeStatuses = array(
			'completed' => __('Order Status Completed:', 'rbipayment'),
			'refunded'  => __('Order Status Refunded:', 'rbipayment'),
			'cancelled' => __('Order Status Cancelled:', 'rbipayment'),
			'failed'    => __('Order Status Failed:', 'rbipayment'),
		);

		foreach ($typeStatuses as $key => $label) {
			$common_settings_fields['order_status_' . $key . '_id'] = array(
				'title'   => $label,
				'type'    => 'select',
				'options' => $order_statuses,
				'default' => "wc-$key"
			);
		}

		$common_settings_fields[] = array(
			'title' => __('Others', 'rbipayment'),
			'type'  => 'title',
			'class' => 'tab-advanced',
		);

		$common_settings_fields['geo_zone_id'] = array(
			'title'   => __('Geo Zone:', 'rbipayment'),
			'type'    => 'select',
			'options' => $zonesOption
		);

		$common_settings_fields['description'] = array(
			'title' => __('Order description:', 'rbipayment'),
			'type'  => 'text',
			'class' => isset(RBIPayment::$invalidFields['description']) ? 'rbipayment-error-field' : '',
		);

		$this->form_fields = array_merge($common_settings_fields);
	}

	public function process_admin_options() {
		if (RBIPayment::$preventSave !== false) {
			return;
		}

		parent::process_admin_options();
	}

	private function _validateZones($zone) {
		if ($zone == '-1') {
			return true;
		}

		if (!isset(WC()->customer) || !WC()->customer) {
			return false;
		}

		$package = array();
		$package['destination']['country'] = WC()->customer->get_billing_country();
		$package['destination']['state'] = WC()->customer->get_billing_state();
		$package['destination']['postcode'] = WC()->customer->get_billing_postcode();

		$billing_zone = WC_Shipping_Zones::get_zone_matching_package($package);
		$billing_zone = $billing_zone->get_data();

		$zoneId = 0;
		if (isset($billing_zone['zone_id']) && $billing_zone['zone_id']) {
			$zoneId = $billing_zone['zone_id'];
		} elseif (isset($billing_zone['id']) && $billing_zone['id']) {
			$zoneId = $billing_zone['id'];
		}

		if ($zoneId == $zone) {
			return true;
		}

		return false;
	}

	/** checkout logic */

	public function is_available() {
		if (!$this->_validateZones($this->get_option('geo_zone_id'))) {
			return false;
		}

		return parent::is_available();
	}

	public function getCustomerData($key) {
		$customerField = WC()->customer->{'get_' . $key}();
		return $customerField ? $customerField : WC()->customer->{'get_billing_' . $key}();
	}

	public function getPayload($order) {
		$consumer = [
			"email" => substr($this->getCustomerData('email'), 0, 255),
			"firstName" => substr($this->getCustomerData('first_name'), 0, 32),
			"lastName" => substr($this->getCustomerData('last_name'), 0, 32),
			"phone" => WC()->customer->get_billing_phone(),
			"ipAddress" => $_SERVER['REMOTE_ADDR'],
			"mobilePhone" => "",
			"workPhone" => ""
		];

		$consumer['phone'] = preg_replace('/(?!\+)\D/', '', $consumer['phone']);
		$consumer['phone'] = substr($consumer['phone'], 0, 1) . str_replace('+', '', substr($consumer['phone'], 1, 14));

		$items = [];
		$cart_products = WC()->cart->get_cart();
		foreach ($cart_products as $cart_product) {
			$product = new WC_Product( $cart_product['product_id'] );

			$items[] = [
				"description" => substr($product->get_name(), 0, 100),
				"numberOfItems" => (int)$cart_product['quantity'],
				"price" => $this->rbi->convertPrice(wc_get_price_including_tax($product))
			];
		}

		$iframe = $this->rbi->get('payment_form') == 'iframe' ? '&iframe=true' : '';

		$data = [
			"billingAddress" => [
				"addressStreet1" => substr(WC()->customer->get_billing_address_1(), 0, 50),
				"addressStreet2" => substr(WC()->customer->get_billing_address_2(), 0, 50),
				"addressStreet3" => "",
				"city" => substr(WC()->customer->get_billing_city(), 0, 50),
				"country" => $this->rbi->getCountryIso3(WC()->customer->get_billing_country()),
				"firstName" => substr(WC()->customer->get_billing_first_name(), 0, 32),
				"lastName" =>substr(WC()->customer->get_billing_last_name(), 0, 32),
				"postalCode" => substr(WC()->customer->get_billing_postcode(), 0, 16),
				"state" => '',
			],
			"consumer" => $consumer,
			"invoice" => [
				"amount" => $this->rbi->convertPrice(WC()->cart->get_total('')),
				"currency" => $this->rbi_currency,
				"description" => $this->rbi->get('description'),
				"items" => $items,
				"merchantOrderReference" => $order->get_id()
			],
			"paymentMethodPreference" => "CARD",
			"shippingAddress" => [
				"addressStreet1" => substr(WC()->customer->get_shipping_address_1(), 0, 50),
				"addressStreet2" => substr(WC()->customer->get_shipping_address_2(), 0, 50),
				"addressStreet3" => "",
				"city" => substr(WC()->customer->get_shipping_city(), 0, 50),
				"country" => $this->rbi->getCountryIso3(WC()->customer->get_shipping_country()),
				"firstName" => substr(WC()->customer->get_shipping_first_name(), 0, 32),
				"lastName" => substr(WC()->customer->get_shipping_last_name(), 0, 32),
				"postalCode" => substr(WC()->customer->get_shipping_postcode(), 0, 16),
				"state" => '',
			],
			"isProduction" => $this->rbi->get('mode') == 'production',
			"urls" => [
				"cancelUrl" => $this->callback('cancel') . "&orderId={$order->get_id()}$iframe&headless=true",
				"failUrl" => $this->callback('failure') . "&orderId={$order->get_id()}$iframe&headless=true",
				"successUrl" => $this->callback('success') . "&orderId={$order->get_id()}$iframe&headless=true",
				"notificationUrl" => $this->callback('notify') . "&headless=true",
			]
		];

		return $data;
	}

	public function createOrderEntry($order) {
		$data = $this->getPayload($order);
		unset(WC()->session->error);
		$error = '';

		$result = $this->rbi->curl(json_encode($data), RbiLib::ORDERS_URL, [
			"Accept: application/json",
			"Content-Type: application/json",
			"Authorization: Bearer " . $this->rbi->getBearerToken()
		]);

		if (isset($result['response']['orderIdentification'])) {
			return $result['response'];
		} elseif (isset($result['response']['message'])) {
			$message = '';
			if (isset($result['response']['errors'][0]['message'])) {
				$message = $result['response']['errors'][0]['message'];
			}

			$field = '';
			if (isset($result['response']['errors'][0]['fieldName'])) {
				$field = $result['response']['errors'][0]['fieldName'];
			}

			if ($field || $message) {
				$result['response']['message'] .= "<br> $field - $message";
			}

			$error = $result['response']['message'];
		} else {
			$error = _('error_order_entry', 'rbipayment');
		}

		if ($error) {
			WC()->session->set('error', $error);
			wc_add_notice($error, 'error');
		}
	}

	public function createCheckoutSession($order, $orderIdentification) {
		$data = $this->getPayload($order);
		$data['urls']['cancelUrl'] = str_replace("orderId={$order->get_id()}", "orderId={$orderIdentification}", $data['urls']['cancelUrl']);
		$data['urls']['failUrl'] = str_replace("orderId={$order->get_id()}", "orderId={$orderIdentification}", $data['urls']['failUrl']);
		$data['urls']['successUrl'] = str_replace("orderId={$order->get_id()}", "orderId={$orderIdentification}", $data['urls']['successUrl']);

		unset(WC()->session->error);
		$error = '';

		$result = $this->rbi->curl(json_encode($data), RbiLib::ORDERS_URL . "/$orderIdentification/checkout" , [
			"Accept: application/json",
			"Content-Type: application/json",
			"Authorization: Bearer " . $this->rbi->getBearerToken()
		]);

		if (isset($result['response']['paymentRedirectURL'])) {
			return $result['response'];
		} elseif (isset($result['response']['message'])) {
			$message = '';
			if (isset($result['response']['errors'][0]['message'])) {
				$message = $result['response']['errors'][0]['message'];
			}

			$field = '';
			if (isset($result['response']['errors'][0]['fieldName'])) {
				$field = $result['response']['errors'][0]['fieldName'];
			}

			if ($field || $message) {
				$result['response']['message'] .= "<br> $field - $message";
			}

			$error = $result['response']['message'];
		} elseif (isset($result['error'])) {
			$error = $result['error'];
		} else {
			$error = _('error_checkout_session', 'rbipayment');
		}

		if ($error) {
			WC()->session->set('error', $error);
			wc_add_notice($error, 'error');
		}
	}

	public function process_payment($order_id) {
		$order = new WC_Order($order_id);
		$rbi_order = Rbipayment_Order::getByOrderId($order_id);

		if ($order) {
			if (empty(WC()->session->rbi_order[$order_id])) {
				$orderEntry = $this->createOrderEntry($order);
			} else {
				$orderEntry = WC()->session->rbi_order[$order_id];
			}

			if (isset($orderEntry['orderIdentification'])) {
				if (empty(WC()->session->rbi_order[$order_id])) {
					unset(WC()->session->rbi_order);
					WC()->session->set('rbi_order', [$order_id => $orderEntry]);
				}

				$result = $this->createCheckoutSession($order, $orderEntry['orderIdentification']);

				$data = [
					'order_id' => $order_id,
					'orderIdentification' => $orderEntry['orderIdentification'],
					'request' => $orderEntry,
					'mode' => $this->rbi->get('mode'),
					'phpsessid' => session_id(),
					'currency' => $this->rbi_currency,
					'currency_value' => $this->rbi->convertPrice(1)
				];

				foreach ($data as $key => $value) {
					$rbi_order->setValue($key, $value);
				}
				$rbi_order->save();

				if (isset($result['paymentRedirectURL'])) {
					$lang = substr(get_bloginfo("language"), 0, 2);
					$result['paymentRedirectURL'] .= '&preferredLocale=' . $lang;

					if ($this->has_fields()) {
						$result['paymentRedirectURL'] .= '&mode=frameless';
						$this->has_fields = true;
					}

					$this->action = $result['paymentRedirectURL'];
				}
			}
		}

		if ($this->has_fields() && $this->action) {
			echo json_encode([
				'action' => $this->action,
				'payment_method' => $this->id
			]);
			die;
		}

		return [
			'result' => $this->action ? 'success' : 'failure',
			'redirect' => $this->action,
		];
	}

	public function payment_fields() {
		ob_start();
		parent::payment_fields();
		if ($this->has_fields()) {
			?>
				<div id="rbi-modal"><iframe src="" frameborder="0"></iframe></div>
			<?php
		}
		echo ob_get_clean();
	}

	public function restoreSession($phpsessid) {
		session_abort();
		session_id($phpsessid);
		session_start();
	}

	public function iframe($redirect = true) {
		if ($this->rbi->get('payment_form') == 'iframe' && $_GET['iframe'] == 'true') {
			$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$actual_link = str_replace('iframe=true', 'iframe=false', $actual_link);

			if (!$redirect) {
				$actual_link = '';
			}

			echo "<script>parent.closeIframePopup('$actual_link');</script>";
			die;
		}
	}

	public function success() {
		$this->iframe();
		$success = false;

		$orderIdentification = isset($_GET['orderId']) ? $_GET['orderId'] : '';
		$rbi_order = Rbipayment_Order::getRbiOrder($orderIdentification);
		$order = [];

		if ($rbi_order->exists()) {
			$order = wc_get_order($rbi_order->getValue('order_id'));
		}

		if ($order) {
			$success = true;
		} else {
			$text_error = __('The order does not exist!', 'rbipayment');
		}

		if ($success) {
			unset(WC()->session->rbi_order);
			wp_redirect($order->get_checkout_order_received_url());
		} else {
			wc_add_notice($text_error, 'error');
			wp_redirect(wc_get_checkout_url());
		}
		die;
	}

	public function failure() {
		$this->iframe();

		$orderIdentification = isset($_GET['orderId']) ? $_GET['orderId'] : '';
		$rbi_order = Rbipayment_Order::getRbiOrder($orderIdentification);
		$order = [];

		if ($rbi_order->exists()) {
			$order = wc_get_order($rbi_order->getValue('order_id'));
		}

		$response = $rbi_order->getValue('response');
		if (!empty($response['transaction']['status']) && $response['transaction']['status'] == 'FAILED') {
			$text_error = $response['transaction']['statusMessage'];
		}

		if (!$order) {
			$text_error = __('The order does not exist!', 'rbipayment');
		}

		wc_add_notice($text_error, 'error');
		wp_redirect(wc_get_checkout_url());
	}

	public function cancel() {
		$this->iframe();

		$orderIdentification = isset($_GET['orderId']) ? $_GET['orderId'] : '';
		$rbi_order = Rbipayment_Order::getRbiOrder($orderIdentification);
		$order = [];

		if ($rbi_order->exists()) {
			$order = wc_get_order($rbi_order->getValue('order_id'));
		}

		if ($order) {
			$order->update_status($this->rbi->get('order_status_cancelled_id'));
		} else {
			$text_error = __('The order does not exist!', 'rbipayment');
		}

		$response = $rbi_order->getValue('response');
		if (!empty($response['transaction']['status']) && $response['transaction']['status'] == 'FAILED') {
			$text_error = $response['transaction']['statusMessage'];
		}

		wc_add_notice($text_error, 'error');
		wp_redirect(wc_get_checkout_url());
		die;
	}

	public function notify() {
		$response_raw = file_get_contents('php://input');
		$response = json_decode($response_raw, true);

		if (empty($response['order']['orderIdentification'])) {
			return;
		}

		$rbi_order = Rbipayment_Order::getRbiOrder($response['order']['orderIdentification']);

		if (!$rbi_order->exists()) {
			return;
		}

		$curl = $this->rbi->curl(
			[],
			$this->rbi->getStatusUrl($rbi_order, $response['transaction']['transactionId']),
			[
				"Accept: application/json",
				"Authorization: Bearer " . $this->rbi->getBearerToken()
			]
		);

		$response = $curl['response'];

		$order_status = '';
		$order = wc_get_order($rbi_order->getValue('order_id'));

		if ($response['transaction']['transactionType'] == 'REFUND') {
			if ($response['transaction']['status'] == 'SUCCESS') {
				$transactionAmount = $response['transaction']['transactionAmount'];
				$transactionId = $response['transaction']['transactionId'];

				$alreadyRefunded = false;
				if ($refundResponse = $rbi_order->getValue('refund_response')) {
					$savedRefundTransactionId = isset($refundResponse['transaction']['transactionId']) ? $refundResponse['transaction']['transactionId'] : '';
					if ($savedRefundTransactionId == $transactionId) {
						$alreadyRefunded = true;
					}
				}

				if (!$alreadyRefunded) {
					$order_status = $this->rbi->get('order_status_refunded_id');
					$rbi_order->setValue('refunded_amount', $rbi_order->getValue('refunded_amount') + $transactionAmount);
				}
			}

			$rbi_order->setValue('refund_response', $response);
		} else {
			if ($response['transaction']['status'] == 'SUCCESS') {
				$order->payment_complete();
				wc_reduce_stock_levels($order->get_id());
				WC()->cart->empty_cart();
				$order_status = $this->rbi->get('order_status_completed_id');
			} elseif ($response['transaction']['status'] == 'FAILED') {
				WC()->session->set( 'order_awaiting_payment', false );
				$order_status = $this->rbi->get('order_status_failed_id');
			}

			$rbi_order->setValue('response', $response);
		}

		if ($order_status) {
			$order->add_order_note($response['transaction']['statusMessage']);
			$order->update_status($order_status);
			$rbi_order->save();
		}

		die;
	}
}
