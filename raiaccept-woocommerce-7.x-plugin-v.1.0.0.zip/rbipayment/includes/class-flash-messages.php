<?php
/**
 * Raiffeisenbank International payment module
 *
 * @author Extensa Web Development Ltd. <support@extensadev.com>
 * @copyright Copyright (c) 2023 RBI
*/

final class RBIFlashMessages
{
	static $messages = array();
	static $registry = array();

	static public function addMessage($message, $type)
	{
		if (isset($_COOKIE['rbipayment_messages']) && !count(self::$messages)) {
			self::$messages = json_decode(base64_decode($_COOKIE['rbipayment_messages']), true);
		}
		self::$messages[] = array(
			'message' => $message,
			'type'	=> $type
		);
		setcookie('rbipayment_messages', base64_encode(json_encode(self::$messages, JSON_UNESCAPED_UNICODE)), time() + 100, '/');
	}

	static public function getMessages()
	{
		$messages = null;
		if (isset($_COOKIE['rbipayment_messages'])) {
			$messages = json_decode(base64_decode($_COOKIE['rbipayment_messages']), true);
			setcookie('rbipayment_messages', '', time(), '/');
		}

		return $messages;
	}

	static public function register($key, $value)
	{
		if (isset($_COOKIE['rbipayment_registry']) && !count(self::$registry)) {
			self::$registry = json_decode(base64_decode($_COOKIE['rbipayment_registry']), true);
		}
		self::$registry[$key] = $value;

		setcookie('rbipayment_registry', base64_encode(json_encode(self::$registry, JSON_UNESCAPED_UNICODE)), time() + 100, '/');
	}

	static public function registry($key)
	{
		if (isset($_COOKIE['rbipayment_registry'])) {
			$messages = json_decode(base64_decode($_COOKIE['rbipayment_registry']), true);
			if (isset($messages[$key])) {
				$message = $messages[$key];
				unset($messages[$key]);
				setcookie('rbipayment_registry', base64_encode(json_encode($messages, JSON_UNESCAPED_UNICODE)), time() + 100, '/');
				return $message;
			}
		}

		return null;
	}
}
