jQuery(document).ready(function() {
	jQuery('#woocommerce_rbipayment_mode').change(function() {
		showHide();
	});
	showHide();

	jQuery('.rbi.nav-tab-wrapper .nav-tab').click(function() {
		jQuery('.rbi.nav-tab-wrapper .nav-tab').removeClass('nav-tab-active');
		jQuery(this).addClass('nav-tab-active');
		selected_tab = jQuery(this).attr('href').replace('#', '');
		not_selected_tab = jQuery('.rbi.nav-tab-wrapper .nav-tab:not(.nav-tab-active)').attr('href').replace('#', '');

		jQuery(`.${selected_tab}, .${selected_tab} + table`).show();
		jQuery(`.${not_selected_tab}, .${not_selected_tab} + table`).hide();
	});

	jQuery(document).on('change', '#woocommerce_rbipayment_currency', function() {
		showHideCurrencyRates()
	});
	showHideCurrencyRates();
});

function showHideCurrencyRates() {
	jQuery('.currency').text(jQuery('#woocommerce_rbipayment_currency').val());
	if (jQuery('#woocommerce_rbipayment_currency').val() !== '0') {
		jQuery('#add_rate').removeClass('hide-all');
		jQuery('[id^="currency_row"]').removeClass('hide-all');
	} else {
		jQuery('#add_rate').addClass('hide-all');
		jQuery('[id^="currency_row"]').addClass('hide-all');
	}
}

function showHide() {
	jQuery('#woocommerce_rbipayment_' + jQuery('#woocommerce_rbipayment_mode').val() + '_username').closest('tr').show();
	jQuery('#woocommerce_rbipayment_' + jQuery('#woocommerce_rbipayment_mode').val() + '_password').closest('tr').show();
	jQuery('#woocommerce_rbipayment_' + jQuery('#woocommerce_rbipayment_mode option:not(:selected)').val() + '_username').closest('tr').hide();
	jQuery('#woocommerce_rbipayment_' + jQuery('#woocommerce_rbipayment_mode option:not(:selected)').val() + '_password').closest('tr').hide();
}