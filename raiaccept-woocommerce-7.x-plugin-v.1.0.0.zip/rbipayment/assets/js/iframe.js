jQuery( document ).on('updated_checkout', function() {
	if (!rbi.description) {
		jQuery('.payment_method_rbipayment.payment_box').addClass('hidden');
	}
});

jQuery( document ).ajaxComplete(function( event, xhr, settings ) {
	if ( settings.url.indexOf('wc-ajax=checkout') != -1 ) {
		data = xhr.responseJSON;
		if (data.action && data.payment_method == rbi.id) {
			jQuery('.woocommerce-error').hide();
			jQuery('#rbi-modal iframe').attr('src', data.action);
			jQuery('body').append('<div class="rbi-modal-backdrop in"></div>');
			jQuery('body').append(jQuery('#rbi-modal'));
			jQuery('#rbi-modal').show();
			jQuery('html').css('overflow', 'hidden');
		}
	}
});

function closeIframePopup(redirectURL = '') {
	jQuery('#rbi-modal').hide();
	jQuery('.payment_box.payment_method_rbipayment').append(jQuery('#rbi-modal'));
	jQuery('.rbi-modal-backdrop').remove();
	jQuery('html').css('overflow', 'auto');

	if (redirectURL) {
		location = redirectURL;
	}
}